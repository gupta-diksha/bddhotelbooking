package demoHotelBooking;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.model.HotelBookingPageFactory;
import com.cg.model.LoginPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefnBooking 
{
	HotelBookingPageFactory registerPage;
	WebDriver driver;
	@Given("^User is on Hotel Booking page$")
	public void user_is_on_Hotel_Booking_page() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\bddsoftwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D:\\bddsoftwares\\bddhtmldemo\\hotelbookingdemo\\hotelbooking.html");
		registerPage = new HotelBookingPageFactory(driver);
	    
	}

	@When("^First name is blank$")
	public void first_name_is_blank() throws Throwable {
		
		registerPage.setFirstName("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please enter the First Name'$")
	public void display_Alert_Please_enter_the_First_Name() throws Throwable
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the First Name";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	   
	}

	@When("^Last name is blank$")
	public void last_name_is_blank() throws Throwable 
	{
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please enter the Last Name'$")
	public void display_Alert_Please_enter_the_Last_Name() throws Throwable
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the Last Name";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	   
	}

	@When("^email is blank$")
	public void email_is_blank() throws Throwable
	{
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("");
		registerPage.clickLoginButton();
	   
	}

	@Then("^Display Alert 'Please enter the Email'$")
	public void display_Alert_Please_enter_the_Email() throws Throwable
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the Email";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	    
	}

	@When("^mobile number is blank$")
	public void mobile_number_is_blank() throws Throwable
	{
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please enter the Mobile No\\.'$")
	public void display_Alert_Please_enter_the_Mobile_No() throws Throwable 
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the Mobile No.";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	    
	}

	@When("^Email entered is invalid$")
	public void email_entered_is_invalid() throws Throwable 
	{
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("adhhffs@gmail");
		registerPage.clickLoginButton();
	}
	
	@Then("^Display Alert 'Please enter valid Email Id\\.'$")
	public void display_Alert_Please_enter_valid_Email_Id() throws Throwable 
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please enter valid Email Id.";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	   
	}

	@When("^Mobile number entered is invalid$")
	public void mobile_number_entered_is_invalid() throws Throwable 
	{
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("4569789654");
		registerPage.clickLoginButton();
	   
	}
	
	@When("^user entered invalid mobile number$")
	public void user_entered_invalid_mobile_number() throws Throwable 
	{
	    
			registerPage.setFirstName("Diksha");
			registerPage.setLastName("Gupta");
			registerPage.setEmail("saytodiksha@gmail.com");
			registerPage.setPhone("45697");
			registerPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please enter valid Contact no\\.'$")
	public void display_Alert_Please_enter_valid_Contact_no() throws Throwable 
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please enter valid Contact no.";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}
	
	@When("^user does not selects gender$")
	public void user_does_not_selects_gender() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.clickLoginButton();
	}

	@Then("^Display Alert for Gender Field$")
	public void display_Alert_for_Gender_Field() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please Select the Gender";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}
	
	@When("^City is not selected$")
	public void city_is_not_selected() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please select City'$")
	public void display_Alert_Please_select_City() throws Throwable
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please select city";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	    
	}
	@When("^State is not selected$")
	public void state_is_not_selected() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		//registerPage.setState("");
		registerPage.clickLoginButton();
	   
	}

	@Then("^Display Alert 'Please select State'$")
	public void display_Alert_Please_select_State() throws Throwable {
		
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please select state";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	    
	}
	
	@When("^user does not selects roomtype$")
	public void user_does_not_selects_roomtype() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert for Roomtype Field$")
	public void display_Alert_for_Roomtype_Field() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please select the Room type";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}
	@When("^card holder name is blank$")
	public void card_holder_name_is_blank() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.setRoomType("AC");
		registerPage.setCardHolderName("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please fill the Card holder name'$")
	public void display_Alert_Please_fill_the_Card_holder_name() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the Card holder name";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	    
	}

	@When("^Debit card number is blank$")
	public void debit_card_number_is_blank() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.setRoomType("AC");
		registerPage.setCardHolderName("Diksha");
		registerPage.setDebitCardNumber("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please fill the Debit card Number'$")
	public void display_Alert_Please_fill_the_Debit_card_Number() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the Debit card Number";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}

	@When("^CVV  is blank$")
	public void cvv_is_blank() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.setRoomType("AC");
		registerPage.setCardHolderName("Diksha");
		registerPage.setDebitCardNumber("78945612");
		registerPage.setCVV("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please fill the CVV'$")
	public void display_Alert_Please_fill_the_CVV() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the CVV";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}

	@When("^expiry month is blank$")
	public void expiry_month_is_blank() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.setRoomType("AC");
		registerPage.setCardHolderName("Diksha");
		registerPage.setDebitCardNumber("78945612");
		registerPage.setCVV("123");
		registerPage.setMonth("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please fill expiration month'$")
	public void display_Alert_Please_fill_expiration_month() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill expiration month";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}

	@When("^expiry year is blank$")
	public void expiry_year_is_blank() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.setRoomType("AC");
		registerPage.setCardHolderName("Diksha");
		registerPage.setDebitCardNumber("78945612");
		registerPage.setCVV("123");
		registerPage.setMonth("08");
		registerPage.setYear("");
		registerPage.clickLoginButton();
	    
	}

	@Then("^Display Alert 'Please fill the expiration year'$")
	public void display_Alert_Please_fill_the_expiration_year() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Please fill the expiration year";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}
	
	@When("^all entries entered are correct$")
	public void all_entries_entered_are_correct() throws Throwable {
		registerPage.setFirstName("Diksha");
		registerPage.setLastName("Gupta");
		registerPage.setEmail("saytodiksha@gmail.com");
		registerPage.setPhone("9569789654");
		registerPage.setGender("Female");
		registerPage.setCity("Chennai");
		registerPage.setState("Tamilnadu");
		registerPage.setRoomType("AC");
		registerPage.setCardHolderName("Diksha");
		registerPage.setDebitCardNumber("78945612");
		registerPage.setCVV("123");
		registerPage.setMonth("08");
		registerPage.setYear("2025");
		registerPage.clickLoginButton();
	}

	@Then("^Redirect the user to Success Page$")
	public void redirect_the_user_to_Success_Page() throws Throwable {
		driver.navigate().to("D:\\bddsoftwares\\bddhtmldemo\\hotelbookingdemo\\success.html");
		
	    
	}


	

	


	
	    
	






}
