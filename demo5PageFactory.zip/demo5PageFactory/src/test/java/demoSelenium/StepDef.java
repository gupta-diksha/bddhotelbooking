package demoSelenium;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.model.LoginPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef 
{
	LoginPageFactory loginPage;
	WebDriver driver;
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
	    
		System.setProperty("webdriver.chrome.driver", "D:\\bddsoftwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D:\\bddsoftwares\\bddhtmldemo\\hotelbookingdemo\\login.html");
		loginPage = new LoginPageFactory(driver);
	}

	@When("^username password is blank$")
	public void username_password_is_blank() throws Throwable 
	{
		loginPage.setUserName("");
		loginPage.setPassword("");
		loginPage.clickLoginButton();
	}

	@Then("^Display Error Message 'Please enter Username'$")
	public void display_Error_Message_Please_enter_Username() throws Throwable 
	{
	    String actualErrMsg=loginPage.getUserNameError();
	    String expErrorMsg= "* Please enter userName.";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.close();
	}

	@When("^username and password are incorrect$")
	public void username_and_password_are_incorrect() throws Throwable
	{
		loginPage.setUserName("Yogini");
		loginPage.setPassword("Naik");
		loginPage.clickLoginButton();
	    
	}

	@Then("^Display Error Message 'Invalid username or password'$")
	public void display_Error_Message_Invalid_username_or_password() throws Throwable 
	{
		String actualErrMsg=driver.switchTo().alert().getText();
	    String expErrorMsg= "Invalid login! Please try again!";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.switchTo().alert().accept();
	    driver.close();
	}

	@When("^username is given but password is blank$")
	public void username_is_given_but_password_is_blank() throws Throwable 
	{
		loginPage.setUserName("Yogini");
		loginPage.setPassword("");
		loginPage.clickLoginButton();
	   
	}

	@Then("^Display Error Message 'Please enter password'$")
	public void display_Error_Message_Please_enter_password() throws Throwable
	{
		String actualErrMsg=loginPage.getPasswordError();
	    String expErrorMsg= "* Please enter password.";
	    Assert.assertEquals(expErrorMsg, actualErrMsg);
	    driver.close();
	}

	@When("^username and password  entered are correct$")
	public void username_and_password_entered_are_correct() throws Throwable 
	{
		loginPage.setUserName("Diksha");
		loginPage.setPassword("123");
		loginPage.clickLoginButton();
	    
	}

	@Then("^Redirect the user to Hotel Booking Page$")
	public void redirect_the_user_to_Hotel_Booking_Page() throws Throwable 
	{
		driver.navigate().to("D:\\bddsoftwares\\bddhtmldemo\\hotelbookingdemo\\hotelbooking.html");
		driver.close();
	}


	
	
	
	
	

}
