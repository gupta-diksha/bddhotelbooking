package com.cg.model;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingPageFactory
{
	
	@FindBy(xpath=".//*[@id='txtFirstName']")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(xpath=".//*[@id='txtLastName']")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(xpath=".//*[@id='txtEmail']")
	@CacheLookup
	WebElement eMail;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phoneNumber;
	
	@FindBy(id="txtGender1")
	WebElement gender1;
	
	@FindBy(id="txtGender2")
	WebElement gender2;
	
	@FindBy(name="city")
	WebElement city;
	
	@FindBy(name="state")
	WebElement state;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[12]/td[2]/input[1]")
	WebElement check1;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[12]/td[2]/input[2]")
	WebElement check2;
	
	@FindBy(name="persons")
	WebElement numPerson;
	
	WebDriver driver;
	
	@FindBy(id="txtCardholderName")
	WebElement cardHolderName;
	
	@FindBy(id="txtDebit")
	WebElement debitCardNumber;
	
	@FindBy(id="txtCvv")
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	WebElement expiryMonth;
	
	@FindBy(id= "txtYear")
	WebElement expiryYear;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement registerBtn;
	
	public HotelBookingPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setFirstName(String fname)
	{
		firstName.sendKeys(fname);
	}
	
	public void setLastName(String lname)
	{
		lastName.sendKeys(lname);
	}
	
	public void setEmail(String email)
	{
		eMail.sendKeys(email);
	}
	
	public void setPhone(String number)
	{
		phoneNumber.sendKeys(number);
	}
	
	public void setGender(String gen)
	{
		if(gen.equalsIgnoreCase("female"))
			gender2.click();
		else
			gender1.click();
	}
	
	public String getCity()
	{
		String name=city.getText();
		return name;
	}
	
	public void setCity(String cityname)
	{
		city.sendKeys(cityname);
	}
	 public void clickLoginButton()
	 {
		 registerBtn.click();
	 }
	 
	 public String getState()
		{
			String name=state.getText();
			return name;
		}
		
		public void setState(String statename)
		{
			Select dropdown= new Select(state);
			dropdown.selectByValue(statename);
		}
		
		public void setRoomType(String type)
		{
			
			if(type.equalsIgnoreCase("ac"))
				check1.click();
			else
				check2.click();
		}
		
		public void setCardHolderName(String name)
		{
			cardHolderName.sendKeys(name);
		}
		public void setDebitCardNumber(String number)
		{
			debitCardNumber.sendKeys(number);
		}
		public void setCVV(String cvvNumber)
		{
			cvv.sendKeys(cvvNumber);
		}
		 public void setMonth(String month)
		 {
			 expiryMonth.sendKeys(month);
		 }
		 public void setYear(String year)
		 {
			 expiryYear.sendKeys(year );
		 }

}
